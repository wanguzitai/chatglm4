BROWSER_SERVER_URL = 'http://localhost:3000'

IPYKERNEL = 'glm-4-demo'

ZHIPU_AI_KEY = ''
COGVIEW_MODEL = 'cogview-3'
