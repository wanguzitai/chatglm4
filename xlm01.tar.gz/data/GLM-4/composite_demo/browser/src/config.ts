export default {
    LOG_LEVEL: 'debug',
    BROWSER_TIMEOUT: 10000,
    BING_SEARCH_API_URL: 'https://api.bing.microsoft.com/v7.0/custom/',
    BING_SEARCH_API_KEY: 'YOUR_BING_SEARCH_API_KEY',
    CUSTOM_CONFIG_ID :  'YOUR_CUSTOM_CONFIG_ID', //将您的Custom Configuration ID放在此处
    HOST: 'localhost',
    PORT: 3000,
};


